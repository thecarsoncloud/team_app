package com.example.codecademy_drivers_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
